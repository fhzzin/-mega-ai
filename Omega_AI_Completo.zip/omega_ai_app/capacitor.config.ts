import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.omegaai.app', appName: 'Omega AI', webDir: 'www' };
export default config;
