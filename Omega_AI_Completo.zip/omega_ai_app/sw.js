const CACHE='omega-ai-v1';
const ASSETS=['./','./index.html','./style.css','./app.js','./manifest.webmanifest','./assets/modes.json'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).catch(()=>caches.match('./index.html'))));});
