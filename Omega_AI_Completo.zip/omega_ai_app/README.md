# Omega AI — pacote de aplicação Android/Web e API

## Incluído nesta versão
- 14 perfis carregados dos arquivos TXT originais em `assets/prompts/` e `assets/modes.json`.
- Interface responsiva em português, seletor de modos, chat e laboratório de código.
- Backend FastAPI com cadastro/login, autenticação por token, conversas e histórico no SQLite.
- Memória vinculada à conta (ou memória local sem login).
- Upload e extração de texto de PDF, DOCX, TXT, MD, CSV e JSON.
- Análise de imagens via endpoint multimodal compatível com OpenAI.
- Chaves do provedor mantidas no servidor por variável de ambiente, não no APK.
- Projeto Capacitor, PWA, Docker e workflow do GitHub Actions para gerar APK de depuração.

## O que ainda depende de configuração externa
1. Hospedar o backend (Render, VPS ou outro serviço) e configurar `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL` e `OMEGA_SECRET`.
2. Para persistência real em produção, usar volume persistente ou PostgreSQL gerenciado; SQLite em disco efêmero pode perder dados em reinicializações.
3. O modelo configurado precisa aceitar visão/imagens para o endpoint `/vision`. A geração de imagem e vídeo não está conectada nesta entrega; exige provedores e endpoints adicionais.
4. O backend atual oferece cadastro/login e histórico. Antes de uso público, adicionar verificação de e-mail, recuperação de senha, rate limiting, política de privacidade, moderação, backups e monitoramento.

## Executar backend localmente
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate | Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edite .env e configure OMEGA_SECRET e AI_API_KEY
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
A API fica em `http://localhost:8000`; documentação em `/docs`.

## Docker
Na pasta `backend`, copie `.env.example` para `.env`, configure os valores e execute:
```bash
docker compose up --build -d
```

## Gerar APK com GitHub Actions
1. Envie todo o conteúdo desta pasta para um repositório GitHub.
2. Na branch `main`, abra **Actions** e execute **Build Omega AI APK** (ou faça push).
3. Quando o workflow terminar, baixe o artefato `omega-ai-debug-apk` e extraia `app-debug.apk`.
4. Configure o endereço HTTPS do backend no diálogo de conta do app.

O workflow cria o projeto Android com Capacitor e compila APK debug. Para distribuição na Play Store, gerar e proteger uma chave de assinatura e compilar uma versão release.

## Observações de segurança
- Nunca coloque a chave de IA no frontend ou no APK.
- Troque o segredo `OMEGA_SECRET` antes de publicar.
- Os prompts importados são tratados como perfis de estilo/especialidade; não autorizam contornar regras de segurança, revelar segredos ou facilitar danos.
- Não exponha o endpoint sem HTTPS em produção.
